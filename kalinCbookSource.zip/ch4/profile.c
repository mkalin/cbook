#include <stdio.h>

#define SizeF 109
#define SizeB  87

void foo() {
  static unsigned n = 0; /* initialized only once */
  if (SizeF == ++n) printf("foo: %i\n", n);
}

void bar() {
  static unsigned n; /* initialized automatically to zero */
  if (SizeB == ++n) printf("bar: %i\n", n);
}

void main() {
  unsigned i = 0, limit_foo = SizeF, limit_bar = SizeB;
  while (i++ < limit_foo) foo(); /* call foo() a bunch of times */

  i = 0;
  while (i++ < limit_bar) bar(); /* call bar() a bunch of times */ 
}
