/* declaration: keyword extern is required, and the variable must not
   be initialized here because it then would be a definition. */
extern int global_num;

void doubleup() {   /* definition: doubleup is declared elsewhere, defined here */
  global_num *= 2;  /* the global_num defined elsewhere, but accessed here */
}
