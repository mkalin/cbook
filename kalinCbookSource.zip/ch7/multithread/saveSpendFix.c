#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

/** To compile: gcc -o saveSpendFix saveSpendFix.c -lpthread **/

static int account = 0;  /** shared storage across the threads **/                    
static pthread_mutex_t lock; /* named lock for clarity */  

void update(int n) {
  if (0 == pthread_mutex_lock(&lock)) { 
    account += n;                       /** critical section **/
    pthread_mutex_unlock(&lock);
  }
}

void* deposit(void* n) {  /** miser code **/                                        
  int limit = *(int*) n, i;
  for (i = 0; i < limit; i++) update(+1); /* add 1 to account */                    
  return NULL;
} /** thread terminates when exiting deposit **/

void* withdraw(void* n) { /** spendt code **/                                  
  int limit = *(int*) n, i;
  for (i = 0; i < limit; i++) update(-1); /* subtract 1 from account */             
  return NULL;
} /** thread terminates when exiting withdraw **/

void report_and_die(const char* msg) {
  fprintf(stderr, "%s\n", msg);
   exit(-1);
}

void main(int argc, char* argv[]) {
  if (argc < 2) report_and_die("Usage: saveSpend <number of operations apiece>\n");
  int n = atoi(argv[1]); /** command-line argument conversion to integer **/
  
  pthread_t miser, spendt; 
  if (pthread_create(&miser, NULL, deposit, &n) < 0) 
    report_and_die("pthread_create: miser");
    
  if (pthread_create(&spendt, NULL, withdraw, &n) < 0) 
    report_and_die("pthread_create: spendt");
    
  pthread_join(miser,  NULL);  /* main thread waits on miser: NULL for exit status */                 
  pthread_join(spendt, NULL);  /* main thread waits on spendt: NULL for exit status */           
  printf("The final account balance is: %10i\n", account);                                
}
