/* compilation: gcc -o greet greet.c -lpthread */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define ThreadCount 4

void* greet(void* my_id) { /* void* is 8 bytes on a 64-bit machine */
  unsigned i, n = ThreadCount;
  for (i = 0; i < n; i++) {
    printf("from thread %ld...\n", (unsigned long) my_id);
    sleep(rand() % 3);
  }
  return 0;
} /* implicit call to pthread_exit(NULL) */

void main() {
  pthread_t threads[ThreadCount];
  unsigned long i;
  for (i = 0; i < ThreadCount; i++) {
    /* four args: pointer to pthread_t instance, attributes, start function,
       and argument passed to start function */
    int flag = pthread_create(threads + i,  /* 0 on success */
                              NULL,
			      greet,
			      (void*) i + 1); 
    if (flag < 0) {
      perror(NULL);
      exit(-1);
    }
  }
  puts("main exiting...");
  pthread_exit(NULL); /* allows other threads to continue execution */
}
