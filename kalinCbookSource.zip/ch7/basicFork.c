#include <sys/types.h> /* just in case... */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void main() {
  signal(SIGCHLD, SIG_IGN);    /* prevents zombie */  
  int n = 777;                 /* both parent and child have a copy */
  
  pid_t pid = fork();                               
  if (-1 == pid) {             /* -1 signals an error */                              
    perror(NULL);
    exit(-1);
  }
  
  if (0 == pid) {           /** child **/                        
    n = n + 10;              
    printf("%i\n", n);      /** 787 ***/               
  }
  else {                    /** parent **/                      
    n = n * 10;
    printf("%i\n", n);      /** 7770 */
  }
}
