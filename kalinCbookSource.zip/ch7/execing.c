#include <sys/types.h>  /* for saftey: maybe there's no unistd.h */
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  pid_t pid = fork();           /* try to create a child process */
  if (-1 == pid) {              /* did the fork() work? */
    perror("fork()");           /* if not, error message and exit */
    exit(-1);
  }
  
  if (!pid) {                                 /* fork() returns 0 to the child */
    char* const args[ ] = 
      {"./cline", "foo", "bar", "123", NULL}; /* some cmd-line args: NULL to terminate */
    int ret = execv("./cline", args);         /* "v" for "vector" */
    if (-1 == ret) {                          /* check for failure */
      perror("execv(...)");
      exit(-1);
    }
    else 
      printf("This should not print!\n");     /* never executes */
  }
  return 0;
}
