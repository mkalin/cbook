#include <stdio.h>

#define Length 8
typedef double doubleV8 __attribute__ ((vector_size (Length * sizeof(double)))); /** critical **/

void main() {
  doubleV8 dataV1 = {1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8};  /* no square brackets on dataV1 */
  doubleV8 dataV2 = {4.4, 6.6, 1.1, 3.3, 5.5, 2.2, 3.3, 5.5};  /* no square brackets on dataV2 */

  doubleV8 add = dataV1 + dataV2;
  doubleV8 mul = dataV1 * dataV2;
  doubleV8 div = dataV1 / dataV2;
  
  int i;
  for (i = 0; i < Length; i++)  
    printf("%f ", add[i]); /* 5.500000 8.800000 4.400000 7.700000 11.000000 8.800000 11.000000 14.300000 */

  putchar('\n');
  for (i = 0; i < Length; i++) 
    printf("%f ", mul[i]); /* 4.840000 14.520000 3.630000 14.520000 30.250000 14.520000 25.410000 48.400000 */

  putchar('\n');
  for (i = 0; i < Length; i++) 
    printf("%f ", div[i]); /* 0.250000 0.333333 3.000000 1.333333 1.000000 3.000000 2.333333 1.600000 */
  
  putchar('\n');
}
