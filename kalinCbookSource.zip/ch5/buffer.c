#include <unistd.h>
#include <stdio.h>

void main() {
  int i = 0, n = 8;
  char byte;
  
  /* unbuffered */
  while (i++ < n) {
    read(0, &byte, 1);   /* read a single byte */
    write(1, &byte, 1);  /* write it */
 }
  
  /* buffered */
  i = 0;
  while (i++ < n) {
    int next = fgetc(stdin); /* char read in a 4-byte int */
    fputc(next, stdout);     /* char written as a 4-byte int */
  }
  putchar('\n');
}
/* in.dat is: 12345678abcdefgh */
