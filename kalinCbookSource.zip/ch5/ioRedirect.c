#include <stdio.h>
#include <unistd.h>
#include <string.h>

#define BuffSize 8

void main() {
  char buffer[BuffSize];  /* 8-byte buffer */
  ssize_t flag = read(0, buffer, sizeof(buffer)); /* 0 == stdin */
  if (flag < 0) {
    perror("Ooops...");            
    return;
  }
  
  char ws = '\t';
  write(1, buffer, sizeof(buffer));        /* 1 == stdout */
  write(1, &ws, 1);                        /* ditto */
  write(2, buffer, sizeof(buffer));        /* 2 == stderr */
  putchar('\n');
}
