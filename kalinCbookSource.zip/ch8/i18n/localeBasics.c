#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main () {      
  setlocale(LC_ALL, ""); /* set current locale for library functions */
  char* prev_locale = setlocale(LC_ALL, NULL);   /* with NULL, a getter, not a setter */
  char* saved_locale = strdup(prev_locale);      /* get a separate copy */
  
  if (NULL == saved_locale) {                    /* verify the copying */
    perror(NULL);  /* out of memory */
    return;
  }
  
  const struct lconv* loc = localeconv();  /* get ptr to current locale struct */
  printf("Currency symbol: %s\n", loc->currency_symbol);
  setlocale(LC_ALL, "en_GB.utf8"); /* english in Great Britain */
  loc = localeconv();
  printf("Currency symbol: %s\n", loc->currency_symbol);

  setlocale(LC_ALL, saved_locale); /* restored saved locale */
  /*...*/
}
