#include <stdio.h>
#include <unistd.h>
#include <regex.h>
#define MaxBuffer  128
#define GroupCount   4 /* entire expression counts as one group by default */

void main() {
  char error[MaxBuffer + 1]; 
  char* inputs[ ] = {"AABC123dd95", "Az4321jb81", "QQ987ii4", 
                     "QQ98ii4", "YTE987ef4", "ARNQ999kk6", NULL};
		     
  const char* regex = "^([A-Z]{2,4})([1-9]{3})([a-k]{2})[0-9]+$"; 
  regex_t regex_comp;
  int flag;
  if ((flag = regcomp(&regex_comp, regex, REG_EXTENDED)) < 0) {
    regerror(flag, &regex_comp, error, MaxBuffer);
    printf("Regex error compiling '%s': %s\n", regex, error);
    return;
  }
  
  unsigned i = 0, j;
  while (inputs[i]) { /* iterate over the inputs */
    regmatch_t groups[GroupCount]; /* for extracting substrings */
    if (REG_NOMATCH == regexec(&regex_comp, inputs[i], GroupCount, groups, 0)) 
      fprintf(stderr, "\t%s is not a valid employee ID.\n", inputs[i]);
    else {
      fprintf(stdout, "\nValid employee ID. %i parts follow:\n", GroupCount);
      for (j = 0; j < GroupCount; j++) {
	if (groups[j].rm_so < 0) break;
	write(1, inputs[i] + groups[j].rm_so, groups[j].rm_eo - groups[j].rm_so);
	write(1, "\n", 1);
      }	
      printf("-----");
    }
    i++; /* loop counter */
  }
  regfree(&regex_comp); /* good idea to clean up */
}
