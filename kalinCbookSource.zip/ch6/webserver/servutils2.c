#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define Backlog  100

void report_and_exit(const char* msg) {
  fprintf(stderr, "%s\n", msg);
  exit(-1); /* EXIT_FAILURE */
}

int get_servsocket(int port) {
  struct sockaddr_in server_addr;

  /** create, bind, listen **/
  /* create the socket, make it non-blocking */
  int sock_fd = socket(PF_INET, SOCK_STREAM, 0); /* internet family, connection-oriented */
  if (sock_fd < 0)
    report_and_exit("socket(...)");

  /* bind to a local address: implementation details */
  memset(&server_addr, 0, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INADDR_ANY;
  server_addr.sin_port = htons(port); /* host to network endian */
  if (bind(sock_fd, (struct sockaddr*) &server_addr, sizeof(server_addr)) < 0)
    report_and_exit("bind(...)");

  /* listen for connections */
  if (listen(sock_fd, Backlog) < 0) report_and_exit("listen(...)");
  return sock_fd;
}
