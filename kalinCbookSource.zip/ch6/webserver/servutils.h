extern void log_client(struct in_addr* addr);
extern void report_and_exit(const char* msg);
extern int get_servsocket(int port);
extern void get_response(const char[ ], const char[ ]);

