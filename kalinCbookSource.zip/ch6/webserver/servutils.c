#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <arpa/inet.h>

#define BuffSize 256

void log_client(struct in_addr* addr) {
  char buffer[BuffSize + 1];
  if (inet_ntop(AF_INET, addr, buffer, sizeof(buffer))) /* NULL? */
    fprintf(stderr, "Client connected from %s...\n", buffer);
}

void get_response(char request[ ], char response[ ]) {
  strcpy(response, "HTTP/1.1 200 OK\n");                 /* start line */
  strcat(response, "Content-Type: text/*\n");            /* headers... */
  strcat(response, "Accept-Ranges: bytes\n");
  strcat(response, "Connection: close\n\n");
  strcat(response, "Echoing request:\n");                /* body of response */
  strcat(response, request);
}
