#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int get_connection(const char* host, const char* port) {
  struct addrinfo hints, *result, *next;
  int sock_fd, flag;
  memset(&hints, 0, sizeof(struct addrinfo)); /* zero out the structure */
  hints.ai_family = AF_UNSPEC;                /* IPv4 or IPv6 */
  hints.ai_socktype = SOCK_STREAM;            /* connection-based, TCP */
  hints.ai_flags = 0;                         /* various possibilities here */
  hints.ai_protocol = 0;                      /* any protocol */
  
  if ((flag = getaddrinfo(host, port, &hints, &result)) < 0) {  /* error? */
    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(flag));   /* messages */
    exit(-1);                                                   /* failure */
  }
  
  /* Iterate over the list of addresses until one works. */
  for (next = result; next; next = next->ai_next) {
    sock_fd = socket(next->ai_family, next->ai_socktype, next->ai_protocol);
    if (-1 == sock_fd) continue;                                        /* failure */
    if (connect(sock_fd, next->ai_addr, next->ai_addrlen) != -1) break; /* success */              
    close(sock_fd);                                           /* close and try again */
  }
  
  if (!next) {
    fprintf(stderr, "can't find an address\n");
    exit(-1);
  }
  freeaddrinfo(result); /* clean up storage no longer needed */
  
  /* Set a timeout on read operations. */
  struct timeval timeout;      
  timeout.tv_sec = 2;  /* seconds */
  timeout.tv_usec = 0;
  if (setsockopt(sock_fd, SOL_SOCKET, SO_RCVTIMEO, 
                 (char*) &timeout, sizeof(timeout)) < 0) {
    fprintf(stderr, "setsockopt failed\n");
    exit(-1);
  }
  return sock_fd;
}
