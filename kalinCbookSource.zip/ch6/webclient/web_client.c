#include <unistd.h>  /* low-level I/O */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>  /* exit */
#include <errno.h>

#define BuffSize   2048  /* bytes */

extern int get_connection(const char*, const char*);

void main() {
  const char* host = "www.google.com";    /* symbolic IP address */
  const char* port = "80";                /* standard port for HTTP connections */
  const char* request = "GET / HTTP/1.1\nHost: www.google.com\r\n\r\n";
  ssize_t count;
  char buffer[BuffSize];
  
  /* connect */
  int sock_fd = get_connection(host, port);
  if (sock_fd < 0) {            
    fprintf(stderr, "Can't connect\n");
    exit(-1);
  }
  
  /* send request */
  if (write(sock_fd, request, strlen(request)) < 0) {
    fprintf(stderr, "Can't write request\n");
    exit(-1);
  }
  
  /* get and write response */
  unsigned read_count = 0, total_bytes = 0;
  memset(buffer, 0, BuffSize); /* clear the buffer for reading */
  
  while (1) {
    count = read(sock_fd, buffer, sizeof(buffer));
    
    if (EWOULDBLOCK == errno || 0 == count) break; /* EWOULDBLOCK on timeout */
    if (-1 == count) continue;  /* continue on non-fatal error */
    
    write(1, buffer, count);
    read_count++; total_bytes += count;  
  }
  close(sock_fd);
  fprintf(stderr, "\n\n%u bytes read in %u separate reads.\n", total_bytes, read_count);
}
