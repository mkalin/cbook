#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

void main() {
  fd_set fds;         /* set of file descriptors */
  struct timeval tv;
  int flag;
  char byte;

  FD_ZERO(&fds);      /* clear the set of fds */
  FD_SET(0, &fds);    /* 0 == standard input */
  tv.tv_sec = 5;
  tv.tv_usec = 0;
  
  flag = select(FD_SETSIZE,  /* how many file descriptors */
                &fds,        /* file descriptors for readers */
		NULL,        /* no writers */
		NULL,        /* no exceptions */
		&tv);        /* timeout info */
  
  if (-1 == flag) 
    perror("select error");
  else if (flag) {          /* flag == 1 == true */
    read(0, &byte, 1);      /* read the byte */
    puts("data read");
  }
  
  if (flag)
    printf("The byte value is: %c\n", byte);
}
