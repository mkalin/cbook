#include "wcSSL.h"

void report_exit(const char* msg) {
  puts(msg);
  exit(-1);
}

void load_SSL() {  /* load various OpenSSL libraries */
  OpenSSL_add_all_algorithms();
  ERR_load_BIO_strings();
  ERR_load_SSL_strings();
  SSL_load_error_strings();
  if (SSL_library_init() < 0) report_exit("SSL_library_init()");
}

int verify_dc(int ver, X509_STORE_CTX* x509_ctx) {  /* stub function */
  /* In production, a full verification would be needed. */
  return 1;
}

/* Extract the subject line for the certificate, then free storage. */
void view_cert(SSL* ssl, BIO* out) {
  X509* cert = SSL_get_peer_certificate(ssl);
  if (NULL == cert) report_exit("SSL_get_peer_certificate(...)");

  X509_NAME* cert_name = X509_NAME_new();
  cert_name = X509_get_subject_name(cert);
  BIO_printf(out, "Certificate subject:\n");
  X509_NAME_print_ex(out, cert_name, 0, 0);
  BIO_printf(out, "\n");
  X509_free(cert);
}

void cleanup(BIO* out, BIO* web, SSL_CTX* ctx) {
  if (out) BIO_free(out);
  if (web) BIO_free_all(web); /* handles nested frees */
  if (ctx) SSL_CTX_free(ctx); /* ditto */
}
