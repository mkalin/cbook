#include <stdio.h>

void main() {
  int table[3][4] = {{1, 2, 3, 4},  /* row 1 */
                     {9, 8, 7, 6},  /* row 2 */
		     {3, 5, 7, 9}}; /* row 3 */
  int i, j;
  
  for (i = 0; i < 3; i++)         /** outer loop: 3 rows **/
    for (j = 0; j < 4; j++)       /** inner loop: 4 cols per row **/
      printf("%i ", table[i][j]);
  printf("\n");
  
  int* ptr = (int*) table;        /** ptr points to an int **/
  for (i = 0; i < 12; i++)        /** 12 ints (3 rows, 4 cols each) **/
    printf("%i ", ptr[i]);
  printf("\n");
}
