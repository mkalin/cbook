#include <stdio.h>
#define Size 8

void main() {
  int arr[Size];               /* storage from the stack -- uninitialized */
  int i;
  for (i = 0; i < Size; i++) { /* iterate over the array */
    arr[i] = i + 1;            /* assign a value to each element */
    printf("arr[%i] = %i\n", arr[i], i + 1);
  }
}
