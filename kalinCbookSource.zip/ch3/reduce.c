#include <stdio.h>
#define Size 30

/* pointer to function with two arguments (int array and length), returns an int */ 
typedef unsigned (*reducer)(unsigned list[], unsigned len); /* type name is reducer */	

unsigned sum(unsigned list[], unsigned len) { 
   unsigned sum = 0, i;
   for (i = 0; i < len; i++) sum += list[i];
   return sum;
}

unsigned product(unsigned list[], unsigned len) { 
   unsigned prod = 1, i;
   for (i = 0; i < len; i++) prod *= list[i]; 
   return prod;
}

unsigned reduce(reducer func, unsigned list[], unsigned len) { /* 1st arg: ptr to func */
   return func(list, len); /** invoking a function in the usual way **/
}

int main() {
   unsigned nums[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                      11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
                      21, 22, 23, 24, 25, 26, 27, 28, 29, 30};
		      
   printf("Sum of list:     %i\n", reduce(sum, nums, Size));      /*           465 */
   printf("Product of list: %i\n", reduce(product, nums, Size));  /* 1,409,286,144 */
   return 0;
}
     
