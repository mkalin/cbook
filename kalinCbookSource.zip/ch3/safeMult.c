#include <stdio.h>
#include <limits.h>

int safe_mult(int n1, int n2, int* product) {
  int flag = 0;         /* assume no overflow */
  *product = n1 * n2;   /* potential overflow */
  
  asm("setae %%bl; movzbl %%bl,%0"
      : "=r" (flag)          /* set flag on overflow */
      :                      /* no other inputs  */
      : "%rbx");             /* scratchpad */
  return flag;  /* zero is no overflow, non-zero is overflow */
}

void main() {
  int n;
  char* msg;

  /* no overflow */
  int flag = safe_mult(16, 48, &n);
  msg =  (!flag) ? "Overflow on 16 * 48" : "No overflow on 16 * 48";
  printf("%s: returned product == %i\n", msg, n);

  /* overflow */
  flag = safe_mult(INT_MAX, INT_MAX, &n);
  msg = (!flag) ? "Overflow on INT_MAX * INT_MAX" : "No overflow on INT_MAX * INT_MAX";
  printf("%s: returned product == %i\n", msg, n);	
}
