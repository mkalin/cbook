#include <stdio.h>
#include <stdlib.h> /* malloc, calloc, realloc */
#include <string.h> /* memset */
#define Size 20

void dump(int* ptr, unsigned size) {
  if (!ptr) return; /* do nothing if ptr is NULL */
  int i;
  for (i = 0; i < size; i++) printf("%i ", ptr[i]); /* *(ptr + i) */
  printf("\n");
}

void main() {
  /* allocate */
  int* mptr = malloc(Size * sizeof(int)); /* 20 ints, 80 bytes */
  if (mptr) /* malloc returns NULL (0) if it cannot allocate the storage */
    memset(mptr, -1, Size * sizeof(int)); /* set each byte to -1 */
  dump(mptr, Size);
  
  /* realloc */
  mptr = realloc(mptr, (Size + 8) * sizeof(int)); /* request 8 more */
  if (mptr) dump(mptr, Size + 8);
  /* deallocate */
  free(mptr);
  
  /* calloc */
  mptr = calloc(Size, sizeof(int)); /* calloc initializes the storage to zero */
  if (mptr) {
    dump(mptr, Size);
    free(mptr);
  }
}
