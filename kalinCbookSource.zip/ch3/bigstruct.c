#include <stdio.h>
#define Size 100000 

typedef struct { /* Declare the structure using a typedef for convenience. */
  double nums1[Size];  /* 8 bytes per double */
  double nums2[Size];  /* 8 bytes per double */
  int    nums3[Size];  /* 4 bytes per int */
  float  nums4[Size];  /* 4 bytes per float */
  float  nums5[Size];  /* 4 bytes per float */
  int    n;            /* for demo purposes */
} BigNumsStruct;

void good(BigNumsStruct* ptr) {
  printf("%lu\n", sizeof(ptr));        /* 8 on my machine */
  printf("%i %i\n", (*ptr).n, ptr->n); /* -9876 -9876 */
}

void bad(BigNumsStruct arg) {
  printf("Argument size is: %lu\n", sizeof(arg)); /* 2,800,008 bytes */
}

void main() {
  BigNumsStruct bns;
  bns.n = -9876;
  bad(bns);   /** CAUTION **/
  good(&bns); /* right approach: pass an address */
}
