#include <stdio.h>
#include <math.h> /* pi and e as macros, M_PI and M_E, respectively */

void main() {  
  printf("%0.50f\n", 10.12); /* 10.11999999999999921840299066388979554176330566406250 */

  /* On my handheld calculator: 2.2 * 1234.5678 = 2716.04916 */
  double d1 = 2.2, d2 = 1234.5678;
  double d3 = d1 * d2;
  if (2716.04916 == d3) printf("As expected.\n"); /* does not print */
  else printf("Not as expected: %.16f\n", d3);    /* 2716.0491600000004837 */
  printf("\n");
  
  /* Expected price: $84.83 */
  float price = 4.99f;
  int quantity = 17;
  float total = price * quantity; /* compiler converts quantity to a float value */
  printf("The total price is $%f.\n", total); /* The total price is $84.829994. */
  
  /* e and pi */
  double ans = pow(M_E, M_PI) - M_PI; /* e and pi, respectively */
  printf("%lf\n", ans); /* 19.999100 prints: expected is 19.99909997 */
}

