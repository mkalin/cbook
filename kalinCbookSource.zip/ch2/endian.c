#include <stdio.h>

unsigned int endian_reverse32(unsigned int n) { /* designed for 32 bits, or 4 bytes */
  return (n >> 24)          |  /* leftmost byte becomes rightmost */
    ((n << 8) & 0x00FF0000) |  /* swap the two inner bytes */
    ((n >> 8) & 0x0000FF00) |  /* ditto */
    (n << 24);                 /* rightmost byte becomes leftmost */
}

int main() {
  unsigned num = 17;
  unsigned ans = endian_reverse32(num);
  
  printf("%i (%08x) reversed is %i (%8x)\n", num, num, ans, ans);
  return 0;
}
