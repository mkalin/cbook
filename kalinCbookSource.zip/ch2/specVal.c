#include <stdio.h>
#include <math.h>

/** gcc -o specVal specVal.c -lm **/
void main() {
  printf("Sqrt of -1:    %f\n", sqrt(-1.0F));  /* 1 11111111 10000000000000000000000 */
  printf("Neg. infinity: %f\n", 1.0F / -0.0F); /* 1 11111111 00000000000000000000000 */
  printf("Pos. infinity: %f\n", 1.0F / 0.0F);  /* 0 11111111 00000000000000000000000 */
}

