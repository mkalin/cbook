#include <stdio.h>
#include <wchar.h> /* wchar_t type */

void main() {
  printf("char size:        %lu\n", sizeof(char));    /* 1 (long unsigned) */
  printf("wchar_t size:     %lu\n", sizeof(wchar_t)); /* 4 */

  /* Signed and unsigned variants of each type are of same size. */
  printf("short size:       %lu\n", sizeof(short));       /* 2 */
  printf("int size:         %lu\n", sizeof(int));         /* 4 */
  printf("long size:        %lu\n", sizeof(long));        /* 8 */
  printf("long long size:   %lu\n", sizeof(long long));   /* 8, maybe more */

  /* floating point types are all signed */
  printf("float size:       %lu\n", sizeof(float));         /*  4 */
  printf("double size:      %lu\n", sizeof(double));        /*  8 */
  printf("long double size: %lu\n", sizeof(long double));   /* 16 */
}
