#include <stdio.h>
#include <stdlib.h>  /* rand() */

int g() {
  return rand() %  100; /* % is modulus; hence, a number 0 through 99 */
}

int f(int multiplier) {
  int t = g();
  return t * multiplier;
}

int main() {
  int n = 72;
  int r = f(n);
  printf("Calling f with %i resulted in %i.\n", n, r); /* 5976 on sample run */
  return r; /* not usual, but all that's required is a returned int */
}
