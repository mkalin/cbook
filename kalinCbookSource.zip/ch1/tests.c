#include <stdio.h>

int main() {
  int n = 111, k = 98;
  
  int r = (n > k) ? k + 1 : n - 1;  /* conditional operator */
  printf("r's value is %i\n", r);   /* 99 */

  if (n < k) puts("if");
  else if (r > k) puts("else if");   /** prints **/
  else puts("else");

  r = 0;               /* reset r to zero */
  switch (r) {
  case 0:
    puts("case 0");    /** prints **/
  case 1:
    puts("case 1");    /** prints **/
    break;             /** break out of switch construct **/
  case 2:
    puts("case 2");
    break;             
  case 3:
    puts("case 3");
    break;             
  default:
    puts("none of the above");
  } /* end of switch */
}
