#include <stdio.h>

int main() {
  int n = 27;                             /** 1 **/
  int k = 43;                             /** 2 **/
  printf("%i * %i = %i\n", n, k, n * k);  /** 3 **/
  return 0;                               /** 4 **/
}

