#include <stdio.h>

int main() {
  int n = -1;
  while (1) {  /* 1 == true */
    printf("A non-negative integer, please: ");
    scanf("%i", &n);
    if (n > 0) break;  /* break out of the loop */
  }
  
  printf("n is %i\n", n);
  n = -1;
  do {
     printf("A non-negative integer, please: ");
     scanf("%i", &n); 
  } while (n < 0);
  printf("n is %i\n", n); 
  return 0;
}

