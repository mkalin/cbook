#include <stdio.h>

int main(int argc, char* argv[ ]) {
  if (argc < 2) {
    puts("Usage: cline <one or more cmd-line args>");
    return -1; /** -1 is EXIT_FAILURE **/
  }
  
  puts(argv[0]);   /* executable program's name */

  int i;
  for (i = 1; i < argc; i++)
    puts(argv[i]); /* additional command-line arguments */
  return 0;    /** 0 is EXIT_SUCCESS **/
}

