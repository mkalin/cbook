#include <stdio.h>

/* This definition of add2, occurring as it does _above_ main, doubles as the
   function's declaration: main calls add2 and so the declaration of add2 must
   be visible above the call. If function add2 were _defined_ below main, then
   the function should be declared here above main to avoid compiler warnings. */
int add2(int n1, int n2) { /* definition: the body is enclosed in the braces */
   int sum = n1 + n2;      /* could avoid this step, kept here for verbosity */
   return sum;             /* we could just return n1 + n2 */
}    

int main() {
    int k = -26, m = 44;
    int sum = add2(k, m); /* call the add2 function, save the returned value */
    /* %i means: format as an integer */
    printf("%i + %i = %i\n", k, m, sum); /* output: -26 + 44 = 18 */
    return 0; /* 0 signals n */
}
